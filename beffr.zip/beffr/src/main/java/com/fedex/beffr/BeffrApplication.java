package com.fedex.beffr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeffrApplication {

    public static void main(String[] args) {
        SpringApplication.run(BeffrApplication.class, args);
    }

}
